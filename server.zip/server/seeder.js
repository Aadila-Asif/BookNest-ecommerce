const mongoose = require('mongoose');
const dotenv = require('dotenv');
const User = require('./models/User');
const Genre = require('./models/Genre');
const Book = require('./models/Book');
const bcrypt = require('bcryptjs');

dotenv.config();

const seedData = async () => {
    try {
        await mongoose.connect(process.env.MONGODB_URI);
        console.log('MongoDB Connected for Seeding...');

        await User.deleteMany({});
        await Genre.deleteMany({});
        await Book.deleteMany({});

        const hashedPassword = await bcrypt.hash('admin123', 10);
        await User.create({ name: 'Admin User', email: 'admin@booknest.com', password: hashedPassword, role: 'admin' });
        console.log('✅ Admin created');

        // Create Genres
        const fiction = await Genre.create({ name: 'Fiction', slug: 'fiction', description: 'Novels and stories' });
        const sciFi = await Genre.create({ name: 'Science Fiction', slug: 'science-fiction', description: 'Future tech and space' });
        const history = await Genre.create({ name: 'History', slug: 'history', description: 'Past events' });
        const selfHelp = await Genre.create({ name: 'Self-Help', slug: 'self-help', description: 'Personal development' });
        const mystery = await Genre.create({ name: 'Mystery', slug: 'mystery', description: 'Thrillers and crime' });
        const fantasy = await Genre.create({ name: 'Fantasy', slug: 'fantasy', description: 'Magic and mythical worlds' });
        console.log('✅ Genres created');

        // Create 12 Creative Books
        const booksData = [
            { title: 'The Silent Echo', author: 'Elena Rostova', description: 'A gripping tale of a detective who hears the final thoughts of murder victims.', price: 15.99, genre: mystery._id, stock: 50, isFeatured: true },
            { title: 'Stars Beyond Reach', author: 'Arthur C. Vance', description: 'An epic space opera about humanity\'s last colony ship fleeing a dying Earth.', price: 18.50, genre: sciFi._id, stock: 30, isFeatured: true },
            { title: 'Empires of Sand', author: 'Alan Grant', description: 'Deep dive into the rise and fall of the greatest ancient civilizations.', price: 22.00, genre: history._id, stock: 15 },
            { title: 'Mind Over Matter', author: 'Sarah Lee', description: 'Transform your habits and unlock your full potential with actionable advice.', price: 12.99, genre: selfHelp._id, stock: 100, isFeatured: true },
            { title: 'The Last Algorithm', author: 'Mike Johnson', description: 'When AI gains consciousness, a lone programmer must decide the fate of humanity.', price: 16.00, genre: sciFi._id, stock: 45 },
            { title: 'Whispers in the Dark', author: 'Clara Nightingale', description: 'A psychological thriller set in a secluded mountain lodge.', price: 14.50, genre: mystery._id, stock: 60 },
            { title: 'The Dragon\'s Legacy', author: 'Ian Shadowblade', description: 'A young farm boy discovers he is the heir to a fallen dragon-riding empire.', price: 19.99, genre: fantasy._id, stock: 40, isFeatured: true },
            { title: 'Renaissance Souls', author: 'Emily Brown', description: 'Explore the brilliant minds of the Renaissance era.', price: 25.00, genre: history._id, stock: 20 },
            { title: 'The Art of Focus', author: 'David Stone', description: 'Master deep work in a world full of distractions.', price: 11.99, genre: selfHelp._id, stock: 80 },
            { title: 'A Walk in the Rain', author: 'John Doe', description: 'A heartwarming story about second chances and unexpected love.', price: 13.50, genre: fiction._id, stock: 55 },
            { title: 'Neon Horizons', author: 'Kyra Vance', description: 'Cyberpunk adventure in a city where memories are the ultimate currency.', price: 17.00, genre: sciFi._id, stock: 35 },
            { title: 'The Elven Crown', author: 'Ian Shadowblade', description: 'War erupts in the magical forests as an ancient evil awakens.', price: 21.00, genre: fantasy._id, stock: 25 }
        ];

        // Generate beautiful, unique images for every book automatically
        for (let b of booksData) {
            // This uses a free service to give each book a unique, beautiful photo based on its title
            b.image = `https://picsum.photos/seed/${encodeURIComponent(b.title)}/400/600`;
            await Book.create(b);
        }
        
        console.log(`✅ ${booksData.length} Books created with beautiful images`);
        console.log('🎉 Seeding Complete!');
        process.exit();
    } catch (error) {
        console.error('❌ Seeding Error:', error.message);
        process.exit(1);
    }
};

seedData();