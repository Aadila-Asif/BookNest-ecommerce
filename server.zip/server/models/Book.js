// models/Book.js
const mongoose = require('mongoose');

const bookSchema = new mongoose.Schema({
  title: { type: String, required: true },
  slug: { type: String, unique: true },
  author: { type: String, required: true },
  price: { type: Number, required: true },
  comparePrice: { type: Number },
  description: { type: String, required: true },
  image: { type: String, required: true },
  genre: { type: mongoose.Schema.Types.ObjectId, ref: 'Genre' },
  isbn: String,
  stock: { type: Number, required: true, default: 0 },
  isFeatured: { type: Boolean, default: false },
  isActive: { type: Boolean, default: true }
}, { timestamps: true });

// FIXED: Removed 'next' for Mongoose v7/v8 compatibility
bookSchema.pre('save', function() {
    if (!this.isModified('title')) return;
    this.slug = this.title.toLowerCase().replace(/[^a-z0-9]+/g, '-');
});

module.exports = mongoose.model('Book', bookSchema);