const mongoose = require('mongoose');

const genreSchema = new mongoose.Schema({
    name: { type: String, required: true, unique: true },
    slug: { type: String, unique: true },
    description: String
}, { timestamps: true });

// Automatically create a URL-friendly slug before saving
genreSchema.pre('save', function() {
});
module.exports = mongoose.model('Genre', genreSchema);