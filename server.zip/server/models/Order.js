const mongoose = require('mongoose');

const orderSchema = new mongoose.Schema({
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    orderItems: [{
        book: { type: mongoose.Schema.Types.ObjectId, ref: 'Book' },
        title: String,
        qty: Number,
        price: Number,
        image: String
    }],
    shippingAddress: { 
        name: String, 
        phone: String, 
        street: String, 
        city: String, 
        state: String, 
        zip: String 
    },
    paymentMethod: { type: String, default: 'COD' },
    itemsPrice: Number,
    totalPrice: Number,
    status: { 
        type: String, 
        enum: ['Processing', 'Shipped', 'Delivered', 'Cancelled'], 
        default: 'Processing' 
    },
}, { timestamps: true });

module.exports = mongoose.model('Order', orderSchema);