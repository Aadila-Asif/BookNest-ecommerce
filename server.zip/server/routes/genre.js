const router = require('express').Router();
const { getGenres, createGenre, deleteGenre } = require('../controllers/genreController');
const { protect, admin } = require('../middleware/auth');

router.get('/', getGenres);
router.post('/', protect, admin, createGenre);
router.delete('/:id', protect, admin, deleteGenre);

module.exports = router;