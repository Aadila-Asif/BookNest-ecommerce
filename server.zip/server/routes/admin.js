const router = require('express').Router();
const { protect, admin } = require('../middleware/auth');
const User = require('../models/User');
const Book = require('../models/Book');
const Order = require('../models/Order');

// Get dashboard stats
router.get('/stats', protect, admin, async (req, res) => {
    try {
        const users = await User.countDocuments({ role: 'customer' });
        const books = await Book.countDocuments();
        const orders = await Order.countDocuments();
        const revenue = await Order.aggregate([
            { $match: { status: 'Delivered' } }, 
            { $group: { _id: null, total: { $sum: '$totalPrice' } } }
        ]);
        res.json({ users, books, orders, revenue: revenue[0]?.total || 0 });
    } catch (err) {
        res.status(500).json({ message: 'Server error' });
    }
});

// Get all customers
router.get('/customers', protect, admin, async (req, res) => {
    try {
        const customers = await User.find({ role: 'customer' }).select('-password').sort({ createdAt: -1 });
        res.json(customers);
    } catch (err) {
        res.status(500).json({ message: 'Server error' });
    }
});

module.exports = router;