const router = require('express').Router();
const multer = require('multer');
const path = require('path');
const { getBooks, getBookBySlug, getAdminBooks, createBook, updateBook, deleteBook } = require('../controllers/bookController');
const { protect, admin } = require('../middleware/auth');

const storage = multer.diskStorage({
    destination: 'uploads/',
    filename: (req, file, cb) => {
        cb(null, Date.now() + path.extname(file.originalname));
    }
});

const upload = multer({ storage });

router.get('/', getBooks);
router.get('/admin/all', protect, admin, getAdminBooks);
router.get('/:slug', getBookBySlug);
router.post('/', protect, admin, upload.single('image'), createBook);
router.put('/:id', protect, admin, upload.single('image'), updateBook);
router.delete('/:id', protect, admin, deleteBook);

module.exports = router;