const router = require('express').Router();
const { register, login } = require('../controllers/authController');
const { protect } = require('../middleware/auth');

router.post('/register', register);
router.post('/login', login);
router.get('/me', protect, (req, res) => {
    res.json(req.user);
});

module.exports = router;