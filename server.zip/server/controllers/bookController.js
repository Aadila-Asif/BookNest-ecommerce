const Book = require('../models/Book');

exports.getBooks = async (req, res) => {
    try {
        let query = { isActive: true };
        if (req.query.genre) query.genre = req.query.genre;
        if (req.query.featured === 'true') query.isFeatured = true;
        const books = await Book.find(query).populate('genre', 'name').sort({ createdAt: -1 });
        res.json(books);
    } catch (err) {
        res.status(500).json({ message: 'Server error' });
    }
};

exports.getBookBySlug = async (req, res) => {
    try {
        const book = await Book.findOne({ slug: req.params.slug }).populate('genre');
        if (!book) return res.status(404).json({ message: 'Book not found' });
        res.json(book);
    } catch (err) {
        res.status(500).json({ message: 'Server error' });
    }
};

exports.getAdminBooks = async (req, res) => {
    try {
        const books = await Book.find({}).populate('genre', 'name').sort({ createdAt: -1 });
        res.json(books);
    } catch (err) {
        res.status(500).json({ message: 'Server error' });
    }
};

exports.createBook = async (req, res) => {
    try {
        const { title, author, description, price, comparePrice, genre, isbn, stock, isFeatured } = req.body;
        const image = req.file ? `/uploads/${req.file.filename}` : 'https://placehold.co/400x600/1a1a2e/ffffff?text=No+Image';
        const book = await Book.create({ title, author, description, price, comparePrice, genre, isbn, image, stock, isFeatured });
        res.status(201).json(book);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};

exports.updateBook = async (req, res) => {
    try {
        const book = await Book.findById(req.params.id);
        if (!book) return res.status(404).json({ message: 'Book not found' });
        Object.assign(book, req.body);
        if (req.file) book.image = `/uploads/${req.file.filename}`;
        await book.save();
        res.json(book);
    } catch (err) {
        res.status(500).json({ message: 'Server error' });
    }
};

exports.deleteBook = async (req, res) => {
    try {
        await Book.findByIdAndDelete(req.params.id);
        res.json({ message: 'Book removed' });
    } catch (err) {
        res.status(500).json({ message: 'Server error' });
    }
};