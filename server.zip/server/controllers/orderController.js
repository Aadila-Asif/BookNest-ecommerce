const Order = require('../models/Order');
const Book = require('../models/Book');

// CUSTOMER: Create a new order
exports.createOrder = async (req, res) => {
    try {
        const { orderItems, shippingAddress } = req.body;
        if (!orderItems || orderItems.length === 0) {
            return res.status(400).json({ message: 'No order items' });
        }

        let itemsPrice = 0;

        // Loop through items to check stock and calculate price
        for (let item of orderItems) {
            const book = await Book.findById(item.book);
            if (!book) return res.status(404).json({ message: `Book not found` });
            if (book.stock < item.qty) return res.status(400).json({ message: `Not enough stock for ${book.title}` });
            
            itemsPrice += book.price * item.qty;
            
            // Reduce stock in database
            book.stock -= item.qty;
            await book.save();
        }

        // Create the order
        const order = await Order.create({
            user: req.user._id,
            orderItems,
            shippingAddress,
            itemsPrice,
            totalPrice: itemsPrice // Free shipping for simplicity
        });

        res.status(201).json(order);
    } catch (err) {
        res.status(500).json({ message: 'Server error' });
    }
};

// CUSTOMER: Get my orders
exports.getMyOrders = async (req, res) => {
    try {
        const orders = await Order.find({ user: req.user._id }).sort({ createdAt: -1 });
        res.json(orders);
    } catch (err) {
        res.status(500).json({ message: 'Server error' });
    }
};

// ADMIN: Get all orders
exports.getAllOrders = async (req, res) => {
    try {
        const orders = await Order.find().populate('user', 'name email').sort({ createdAt: -1 });
        res.json(orders);
    } catch (err) {
        res.status(500).json({ message: 'Server error' });
    }
};

// ADMIN: Update order status
exports.updateOrderStatus = async (req, res) => {
    try {
        const order = await Order.findById(req.params.id);
        if (!order) return res.status(404).json({ message: 'Order not found' });
        
        order.status = req.body.status;
        await order.save();
        res.json(order);
    } catch (err) {
        res.status(500).json({ message: 'Server error' });
    }
};