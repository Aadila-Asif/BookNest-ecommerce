const Genre = require('../models/Genre');

// PUBLIC: Get all genres
exports.getGenres = async (req, res) => {
    try {
        const genres = await Genre.find().sort({ name: 1 });
        res.json(genres);
    } catch (err) {
        res.status(500).json({ message: 'Server error' });
    }
};

// ADMIN: Create a genre
exports.createGenre = async (req, res) => {
    try {
        const { name, description } = req.body;
        if (!name) return res.status(400).json({ message: 'Genre name is required' });
        
        const genre = await Genre.create({ name, description });
        res.status(201).json(genre);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};

// ADMIN: Delete a genre
exports.deleteGenre = async (req, res) => {
    try {
        await Genre.findByIdAndDelete(req.params.id);
        res.json({ message: 'Genre removed' });
    } catch (err) {
        res.status(500).json({ message: 'Server error' });
    }
};