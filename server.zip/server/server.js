const express = require('express');
const dotenv = require('dotenv');
const cors = require('cors');
const path = require('path');
const connectDB = require('./config/db');

// Load environment variables
dotenv.config();

// Connect to Database
connectDB();

const app = express();

// Middleware to read JSON data and allow frontend to connect
app.use(cors({ origin: ['http://localhost:5173', 'http://localhost:5174'], credentials: true }));
app.use(express.json());

// Serve uploaded images statically
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// --- IMPORT ALL ROUTES ---
app.use('/api/auth', require('./routes/auth'));
app.use('/api/genres', require('./routes/genre'));
app.use('/api/books', require('./routes/book'));
app.use('/api/orders', require('./routes/order'));
app.use('/api/admin', require('./routes/admin'));

// Simple Test Route
app.get('/api/test', (req, res) => {
  res.json({ message: 'BookNest Backend is working!' });
});

// Global Error Catcher
app.use((err, req, res, next) => {
    res.status(500).json({ message: err.message });
});

// Start the server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));